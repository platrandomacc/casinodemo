export const featuredGames = [
  {
    title: 'Towers',
    provider: 'Flip Bet',
    rtp: '97.4%',
    category: 'Live Casino',
    accent: 'from-[#22C55E]/35 to-[#16A34A]/20',
    image: 'https://cdn.discordapp.com/attachments/1512658367150166178/1516880552639074415/file_000000001a3872078df5e2749b6c87e4.png?ex=6a42185a&is=6a40c6da&hm=3b65f933f4cae04945b8dcc3a6b6fc50170942f0e7d976dec524b4080bebfea9?auto=format&fit=crop&w=900&q=80',
  },
  {
    title: 'Aurora Vault',
    provider: 'Nexora',
    rtp: '96.8%',
    category: 'Slots',
    accent: 'from-[#3B82F6]/30 to-[#22C55E]/10',
    image: 'https://images.unsplash.com/photo-1511882150382-421056c89033?auto=format&fit=crop&w=900&q=80',
  },
  {
    title: 'Midnight Blackjack',
    provider: 'Atlas Play',
    rtp: '98.7%',
    category: 'Table Games',
    accent: 'from-[#16A34A]/20 to-[#22C55E]/20',
    image: 'https://images.unsplash.com/photo-1513151233558-d860c5398176?auto=format&fit=crop&w=900&q=80',
  },
];

export const categories = ['Live', 'Slots', 'Table', 'Jackpots', 'Instant'];
export const providers = ['Lumen Studios', 'Nexora', 'Atlas Play', 'Volt', 'Cinder'];

export const promotions = [
  {
    title: 'Weekend Boost',
    description: 'Double rewards on live dealer tables every Friday to Sunday.',
    value: '25% boost',
  },
  {
    title: 'VIP Lounge Access',
    description: 'Private host invites and higher withdrawal limits for elite players.',
    value: 'Priority',
  },
  {
    title: 'Loyalty Drop',
    description: 'Claim instant free spins on premium slots every 12 hours.',
    value: 'Free spins',
  },
];

export const leaderboards = [
  { name: 'Mina Carter', points: 28450, tier: 'Diamond' },
  { name: 'Rory Hale', points: 25210, tier: 'Gold' },
  { name: 'Kai Laurent', points: 21980, tier: 'Platinum' },
];

export const faqItems = [
  {
    question: 'How quickly can I withdraw?',
    answer: 'Most withdrawals clear within 2 to 4 hours for verified accounts, with higher limits available for VIP members.',
  },
  {
    question: 'Is the platform mobile-friendly?',
    answer: 'Yes. Every experience is optimized for phones, tablets, and desktop displays with consistent performance.',
  },
  {
    question: 'How does responsible play work?',
    answer: 'You can set deposit limits, cooling-off periods, and self-exclusion windows directly from your profile.',
  },
];

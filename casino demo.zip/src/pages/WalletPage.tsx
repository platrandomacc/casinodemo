import { Wallet } from 'lucide-react';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';

export default function WalletPage() {
  return (
    <div className="space-y-6">
      <Card>
        <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <p className="text-sm uppercase tracking-[0.32em] text-[#3B82F6]">Wallet</p>
            <h1 className="mt-3 text-3xl font-semibold text-white">Secure balance and transaction overview.</h1>
          </div>
          <div className="rounded-[18px] border border-[#16A34A]/20 bg-[#16A34A]/10 px-4 py-3 text-[#16A34A]">
            <div className="flex items-center gap-2">
              <Wallet size={18} />
              <span className="font-semibold">$1,248.00</span>
            </div>
          </div>
        </div>
      </Card>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <p className="font-medium text-white">Recent activity</p>
          <div className="mt-4 space-y-3 text-sm text-[#8D95A8]">
            <div className="rounded-[14px] border border-transparent hover:border-sky-500/25/8 hover:border-emerald-500/40 bg-[#171A22] px-4 py-3">Deposit • 09:42 • +$300</div>
            <div className="rounded-[14px] border border-transparent hover:border-sky-500/25/8 hover:border-emerald-500/40 bg-[#171A22] px-4 py-3">Live roulette • 11:10 • -$72</div>
          </div>
        </Card>

        <Card>
          <p className="font-medium text-white">Quick actions</p>
          <div className="mt-4 flex flex-wrap gap-3">
            <Button>Deposit</Button>
            <Button variant="secondary">Withdraw</Button>
          </div>
        </Card>
      </div>
    </div>
  );
}

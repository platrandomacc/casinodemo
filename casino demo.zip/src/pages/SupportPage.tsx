import { MessageCircleMore } from 'lucide-react';
import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';

export default function SupportPage() {
  return (
    <div className="space-y-6">
      <Card>
        <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <p className="text-sm uppercase tracking-[0.32em] text-[#3B82F6]">Support</p>
            <h1 className="mt-3 text-3xl font-semibold text-white">Professional help, available around the clock.</h1>
            <p className="mt-3 max-w-2xl text-sm leading-7 text-[#B7BDCB]">Need assistance with account access, limits, or game questions? Our team is ready to help without friction.</p>
          </div>
          <Button>Contact support</Button>
        </div>
      </Card>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <div className="flex items-center gap-3 text-[#3B82F6]">
            <MessageCircleMore size={18} />
            <p className="font-medium text-white">Live chat</p>
          </div>
          <p className="mt-3 text-sm text-[#8D95A8]">Average response time under three minutes for priority issues.</p>
        </Card>
        <Card>
          <p className="font-medium text-white">Email support</p>
          <p className="mt-3 text-sm text-[#8D95A8]">Send a detailed request to the care desk for account and verification enquiries.</p>
        </Card>
      </div>
    </div>
  );
}

import { ReactNode } from 'react';

interface CardProps {
  children: ReactNode;
  className?: string;
  hover?: boolean;
}

export function Card({ children, className = '', hover = true }: CardProps) {
  return (
    <div
      className={`rounded-[18px] border border-transparent hover:border-sky-500/25/8 hover:border-emerald-500/40 bg-[#12141B]/95 p-5 shadow-soft  ${hover ? 'transition-colors duration-200 ease-out duration-175 hover:-translate-y-1 hover:border-[#22C55E]/30 hover:shadow-[0_16px_40px_rgba(0,0,0,0.24)]' : ''} ${className}`}
    >
      {children}
    </div>
  );
}

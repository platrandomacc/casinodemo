import { ReactNode, ButtonHTMLAttributes } from 'react';

type ButtonVariant = 'primary' | 'secondary' | 'ghost' | 'outline';

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  children: ReactNode;
  variant?: ButtonVariant;
  fullWidth?: boolean;
}

const variantClasses: Record<ButtonVariant, string> = {
  primary: 'bg-gradient-to-r from-[#22C55E] via-[#3B82F6] to-[#22C55E] text-[#08090D] shadow-[0_10px_30px_rgba(216,162,76,0.24)]',
  secondary: 'bg-[#171A22] text-white border border-transparent hover:border-sky-500/25/8 hover:border-emerald-500/40 hover:border-[#22C55E]/40',
  ghost: 'bg-transparent text-[#F7F7F8] hover:bg-white/[0.04]',
  outline: 'border border-[#22C55E]/30 text-[#3B82F6] bg-transparent hover:bg-[#22C55E]/10',
};

export function Button({ children, variant = 'primary', fullWidth = false, className = '', ...props }: ButtonProps) {
  return (
    <button
      className={`inline-flex items-center justify-center rounded-2xl px-4 py-2.5 text-sm font-medium transition-colors duration-200 ease-out duration-200 hover:-translate-y-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#22C55E] ${variantClasses[variant]} ${fullWidth ? 'w-full' : ''} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
}
